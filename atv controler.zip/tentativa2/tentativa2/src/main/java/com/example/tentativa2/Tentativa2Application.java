package com.example.tentativa2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tentativa2Application {

	public static void main(String[] args) {
		SpringApplication.run(Tentativa2Application.class, args);
	}

}
